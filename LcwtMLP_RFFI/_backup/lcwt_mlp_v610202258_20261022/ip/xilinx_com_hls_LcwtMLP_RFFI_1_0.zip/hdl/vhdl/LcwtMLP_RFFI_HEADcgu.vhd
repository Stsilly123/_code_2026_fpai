-- ==============================================================
-- File generated on Tue Oct 20 22:57:52 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_HEADcgu_rom is 
    generic(
             DWIDTH     : integer := 14; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_HEADcgu_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "00000000000001", 1 => "00001110001011", 2 => "00000110001100", 
    3 => "01011101000110", 4 => "11111110111100", 5 => "00111011110011", 
    6 => "00111111001001", 7 => "00001000111010", 8 => "11100000101110", 
    9 => "11111001011100", 10 => "00000110000101", 11 => "11111111100100", 
    12 => "00010100011100", 13 => "00011010010111", 14 => "00010101101011", 
    15 => "11010110010011", 16 => "00011110001110", 17 => "00000100010101", 
    18 => "11011111001001", 19 => "11111110010111", 20 => "11111001101111", 
    21 => "00001101101101", 22 => "11111110111110", 23 => "00010111011000", 
    24 => "00010001000011", 25 => "00000010011010", 26 => "00011111001110", 
    27 => "00100110110010", 28 => "11001011101101", 29 => "00011111100110", 
    30 => "00011000001100", 31 => "11110111010001", 32 => "00011100101001", 
    33 => "00011010111100", 34 => "00101111100010", 35 => "00010011100100", 
    36 => "00010010000110", 37 => "10111010100000" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_HEADcgu is
    generic (
        DataWidth : INTEGER := 14;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_HEADcgu is
    component LcwtMLP_RFFI_HEADcgu_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_HEADcgu_rom_U :  component LcwtMLP_RFFI_HEADcgu_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


