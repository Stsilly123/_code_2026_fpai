-- ==============================================================
-- File generated on Tue Oct 20 22:57:51 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC2_byn_rom is 
    generic(
             DWIDTH     : integer := 14; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC2_byn_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "00010011011010", 1 => "00000100010101", 2 => "11111000000111", 
    3 => "00011111001001", 4 => "11011011111001", 5 => "11111111110111", 
    6 => "00011100010000", 7 => "11111111111011", 8 => "00010101110011", 
    9 => "00001100110010", 10 => "11010101111101", 11 => "00010110001011", 
    12 => "00010110000001", 13 => "11110111111101", 14 => "00100011110000", 
    15 => "11010010101000", 16 => "11111111101111", 17 => "00000000011111", 
    18 => "11101110011000", 19 => "11110010111010", 20 => "00010100110011", 
    21 => "11111001101001", 22 => "11101100000000", 23 => "11100001011110", 
    24 => "11111100111110", 25 => "10111010101110", 26 => "11101101101100", 
    27 => "00011010101110", 28 => "00011001001000", 29 => "11101000111110", 
    30 => "11101110001010", 31 => "00000001001000", 32 => "00010011101100", 
    33 => "00000101000011", 34 => "11110011010101", 35 => "11100110000101", 
    36 => "00000111100101", 37 => "11100111100010" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC2_byn is
    generic (
        DataWidth : INTEGER := 14;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC2_byn is
    component LcwtMLP_RFFI_FC2_byn_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC2_byn_rom_U :  component LcwtMLP_RFFI_FC2_byn_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


