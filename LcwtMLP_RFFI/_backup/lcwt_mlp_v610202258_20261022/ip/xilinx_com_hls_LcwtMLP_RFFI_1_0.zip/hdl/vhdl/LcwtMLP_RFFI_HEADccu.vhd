-- ==============================================================
-- File generated on Tue Oct 20 22:57:52 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_HEADccu_rom is 
    generic(
             DWIDTH     : integer := 13; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_HEADccu_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "0101000010000", 1 => "1111100101001", 2 => "1101011100100", 
    3 => "1011101110001", 4 => "0000111011011", 5 => "1111101111101", 
    6 => "1010111110010", 7 => "1111000010111", 8 => "0001110110110", 
    9 => "1100001010110", 10 => "0001011000000", 11 => "0010111100100", 
    12 => "1101101110101", 13 => "0001101111101", 14 => "1111101110100", 
    15 => "0100100100011", 16 => "1111100010110", 17 => "0011111011100", 
    18 => "1111111111100", 19 => "0001101100010", 20 => "0011001000001", 
    21 => "1111000001101", 22 => "0000100111001", 23 => "1111101001001", 
    24 => "1101111001010", 25 => "0010011010010", 26 => "1101010100010", 
    27 => "0000011110001", 28 => "0010100001111", 29 => "1101001110011", 
    30 => "0001011110001", 31 => "0100110000000", 32 => "1110011110000", 
    33 => "1111101110100", 34 => "1101101001011", 35 => "0000010111101", 
    36 => "1111010111010", 37 => "0001111110000" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_HEADccu is
    generic (
        DataWidth : INTEGER := 13;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_HEADccu is
    component LcwtMLP_RFFI_HEADccu_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_HEADccu_rom_U :  component LcwtMLP_RFFI_HEADccu_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


