-- ==============================================================
-- File generated on Tue Oct 20 22:57:50 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC1_VhK_rom is 
    generic(
             DWIDTH     : integer := 13; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC1_VhK_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "0110100000000", 1 => "1111110000000", 2 => "0000010011001", 
    3 => "0001101110011", 4 => "0000100000110", 5 => "1110000110101", 
    6 => "1110010001101", 7 => "1111000110101", 8 => "1111110101000", 
    9 => "1111011101100", 10 => "0000000000100", 11 => "1111010111001", 
    12 => "1111011011101", 13 => "1011111010011", 14 => "1101001010111", 
    15 => "1111101011101", 16 => "0001110110110", 17 => "0010111001101", 
    18 => "0011001100010", 19 => "0001001011001", 20 => "0000100011111", 
    21 => "0000011101110", 22 => "1101011101011", 23 => "1110110110001", 
    24 => "1110011111110", 25 => "0000110100100", 26 => "1111000001100", 
    27 => "1011001110000", 28 => "0010111011110", 29 => "0111110010010", 
    30 => "1110011111011", 31 => "1101111000000", 32 => "1001010011010", 
    33 => "0001110111000", 34 => "0001000010000", 35 => "0000110110000", 
    36 => "0000111010100", 37 => "0001110111001" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC1_VhK is
    generic (
        DataWidth : INTEGER := 13;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC1_VhK is
    component LcwtMLP_RFFI_FC1_VhK_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC1_VhK_rom_U :  component LcwtMLP_RFFI_FC1_VhK_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


