-- ==============================================================
-- File generated on Tue Oct 20 22:57:50 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC1_8jQ_rom is 
    generic(
             DWIDTH     : integer := 13; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC1_8jQ_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "1101101111000", 1 => "1110100100110", 2 => "0000010001111", 
    3 => "0011111010101", 4 => "0000111000010", 5 => "0011010110101", 
    6 => "0001010010110", 7 => "1111110100111", 8 => "0000111100010", 
    9 => "1101001111101", 10 => "1110101110011", 11 => "0001111110101", 
    12 => "1110100000011", 13 => "0100001110010", 14 => "1111110011011", 
    15 => "1111000011101", 16 => "1011011001000", 17 => "0000011010000", 
    18 => "1111110010110", 19 => "1111011000000", 20 => "1110101110100", 
    21 => "1110011110100", 22 => "1111001010001", 23 => "0011110101010", 
    24 => "1110110110111", 25 => "1100110110011", 26 => "0001001001111", 
    27 => "1100010011001", 28 => "0010010101011", 29 => "0011110001111", 
    30 => "1100100101111", 31 => "0001001010010", 32 => "0000111110011", 
    33 => "1110011110110", 34 => "0011000001010", 35 => "0001111100001", 
    36 => "1110111100000", 37 => "1101011110001" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC1_8jQ is
    generic (
        DataWidth : INTEGER := 13;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC1_8jQ is
    component LcwtMLP_RFFI_FC1_8jQ_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC1_8jQ_rom_U :  component LcwtMLP_RFFI_FC1_8jQ_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


