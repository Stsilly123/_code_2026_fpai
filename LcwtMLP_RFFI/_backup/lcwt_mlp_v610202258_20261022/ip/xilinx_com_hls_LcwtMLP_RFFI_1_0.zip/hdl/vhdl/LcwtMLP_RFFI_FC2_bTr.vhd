-- ==============================================================
-- File generated on Tue Oct 20 22:57:51 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC2_bTr_rom is 
    generic(
             DWIDTH     : integer := 14; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC2_bTr_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "11110010001110", 1 => "00111101101100", 2 => "00101100000001", 
    3 => "00011110001000", 4 => "11010111011001", 5 => "11110000111110", 
    6 => "11111011111110", 7 => "00001011111010", 8 => "11110001110100", 
    9 => "00100001100111", 10 => "11011100111101", 11 => "11100110111011", 
    12 => "00001100001111", 13 => "11110010000001", 14 => "00000101001011", 
    15 => "11101100011110", 16 => "00001101110001", 17 => "10110111000110", 
    18 => "11101101001001", 19 => "00001000101100", 20 => "11111011100110", 
    21 => "00010101001010", 22 => "00010001110010", 23 => "11001110000001", 
    24 => "00011011001000", 25 => "00000001000011", 26 => "00101110111111", 
    27 => "11101110111001", 28 => "00000100010000", 29 => "00010101001101", 
    30 => "11010101111101", 31 => "11111001111100", 32 => "11111101101101", 
    33 => "00100011101110", 34 => "00010000101010", 35 => "11101101001100", 
    36 => "00011011000000", 37 => "11100101111110" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC2_bTr is
    generic (
        DataWidth : INTEGER := 14;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC2_bTr is
    component LcwtMLP_RFFI_FC2_bTr_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC2_bTr_rom_U :  component LcwtMLP_RFFI_FC2_bTr_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


