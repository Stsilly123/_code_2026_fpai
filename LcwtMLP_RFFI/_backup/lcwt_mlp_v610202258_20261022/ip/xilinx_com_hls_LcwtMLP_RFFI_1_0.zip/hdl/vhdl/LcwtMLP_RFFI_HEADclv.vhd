-- ==============================================================
-- File generated on Tue Oct 20 22:57:52 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_HEADclv_rom is 
    generic(
             DWIDTH     : integer := 13; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_HEADclv_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "1111010000001", 1 => "0000101010101", 2 => "1110111110011", 
    3 => "1110111100010", 4 => "1110110010110", 5 => "1111100110111", 
    6 => "0111000011001", 7 => "0000010001001", 8 => "1101110010101", 
    9 => "1100101110001", 10 => "1011110101110", 11 => "1011011000001", 
    12 => "1101100110101", 13 => "0010000110000", 14 => "0000011000000", 
    15 => "1100010110110", 16 => "1111000000101", 17 => "1101011110011", 
    18 => "1100010111100", 19 => "0110010000001", 20 => "1110001100110", 
    21 => "1110010011111", 22 => "0010010110000", 23 => "1111111011010", 
    24 => "1010001000110", 25 => "1100011111011", 26 => "1010011111000", 
    27 => "0011001101000", 28 => "0001000010010", 29 => "0000000100011", 
    30 => "0000101111110", 31 => "0001110011001", 32 => "1011000110110", 
    33 => "1111011010110", 34 => "1100000000110", 35 => "0011000111010", 
    36 => "0100011101000", 37 => "0000100110111" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_HEADclv is
    generic (
        DataWidth : INTEGER := 13;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_HEADclv is
    component LcwtMLP_RFFI_HEADclv_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_HEADclv_rom_U :  component LcwtMLP_RFFI_HEADclv_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


