-- ==============================================================
-- File generated on Tue Oct 20 22:57:50 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC1_QgW_rom is 
    generic(
             DWIDTH     : integer := 14; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC1_QgW_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "10101101100000", 1 => "00110010010011", 2 => "10101110111111", 
    3 => "00011011101000", 4 => "11111000010110", 5 => "10111000100100", 
    6 => "00110011011001", 7 => "11110001011001", 8 => "10100110001110", 
    9 => "01000010110010", 10 => "00000001011101", 11 => "11111000110011", 
    12 => "11110010100110", 13 => "11010101000010", 14 => "00010001110111", 
    15 => "11101100010101", 16 => "11101101110111", 17 => "00111101000110", 
    18 => "00000011110110", 19 => "11010011101010", 20 => "00000101000101", 
    21 => "00101011101101", 22 => "00011111001000", 23 => "11101010010111", 
    24 => "11110110110001", 25 => "11110000011101", 26 => "11110110011101", 
    27 => "01000111011111", 28 => "00000001101101", 29 => "00100101101100", 
    30 => "00100000111000", 31 => "11010001011011", 32 => "11111010001000", 
    33 => "11111000010111", 34 => "00000100111111", 35 => "00110000101110", 
    36 => "00010001011011", 37 => "11110111000011" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC1_QgW is
    generic (
        DataWidth : INTEGER := 14;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC1_QgW is
    component LcwtMLP_RFFI_FC1_QgW_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC1_QgW_rom_U :  component LcwtMLP_RFFI_FC1_QgW_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


