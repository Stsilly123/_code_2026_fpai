-- ==============================================================
-- File generated on Tue Oct 20 22:57:50 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC1_Shg_rom is 
    generic(
             DWIDTH     : integer := 13; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC1_Shg_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "1110001000110", 1 => "1111000111101", 2 => "0001010000101", 
    3 => "0001001011101", 4 => "1001111101010", 5 => "0001011001011", 
    6 => "1011110110110", 7 => "1100101110110", 8 => "0001100111101", 
    9 => "0000001001000", 10 => "1100010111010", 11 => "0001010001110", 
    12 => "1111111010110", 13 => "1010101010101", 14 => "1101000100111", 
    15 => "0110010111000", 16 => "0010011011000", 17 => "1111001000001", 
    18 => "0100000111100", 19 => "0010001011101", 20 => "1110100010010", 
    21 => "1111010001001", 22 => "1111001011100", 23 => "0000000111100", 
    24 => "0001011100110", 25 => "0010010010011", 26 => "0000001101110", 
    27 => "1101101000111", 28 => "0010111111100", 29 => "0001010111011", 
    30 => "1111110001101", 31 => "1101100100001", 32 => "1111111100101", 
    33 => "0001101100010", 34 => "0000101011001", 35 => "0000000101001", 
    36 => "1101110101110", 37 => "0100011010011" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC1_Shg is
    generic (
        DataWidth : INTEGER := 13;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC1_Shg is
    component LcwtMLP_RFFI_FC1_Shg_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC1_Shg_rom_U :  component LcwtMLP_RFFI_FC1_Shg_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


