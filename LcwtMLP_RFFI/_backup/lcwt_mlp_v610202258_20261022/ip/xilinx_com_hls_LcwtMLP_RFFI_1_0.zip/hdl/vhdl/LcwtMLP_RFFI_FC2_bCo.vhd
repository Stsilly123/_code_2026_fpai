-- ==============================================================
-- File generated on Tue Oct 20 22:57:51 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity LcwtMLP_RFFI_FC2_bCo_rom is 
    generic(
             DWIDTH     : integer := 14; 
             AWIDTH     : integer := 6; 
             MEM_SIZE    : integer := 38
    ); 
    port (
          addr0      : in std_logic_vector(AWIDTH-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DWIDTH-1 downto 0);
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of LcwtMLP_RFFI_FC2_bCo_rom is 

signal addr0_tmp : std_logic_vector(AWIDTH-1 downto 0); 
type mem_array is array (0 to MEM_SIZE-1) of std_logic_vector (DWIDTH-1 downto 0); 
signal mem : mem_array := (
    0 => "11110100101010", 1 => "01010110111110", 2 => "00101001110010", 
    3 => "00000101001101", 4 => "00010111000111", 5 => "00010000110000", 
    6 => "11000101010100", 7 => "00001110100001", 8 => "11100011001000", 
    9 => "00000111000010", 10 => "00101001100101", 11 => "11001111001101", 
    12 => "11001110010110", 13 => "11111010101101", 14 => "11011010010010", 
    15 => "00101010011000", 16 => "01000011101110", 17 => "11111011110010", 
    18 => "11110000001110", 19 => "00011101110000", 20 => "00000110001101", 
    21 => "00011101011001", 22 => "11100110000101", 23 => "11111110011111", 
    24 => "00000001001001", 25 => "11100000001010", 26 => "00100100110000", 
    27 => "11011101001001", 28 => "00000111110100", 29 => "00001111111010", 
    30 => "11101001111101", 31 => "00001010010100", 32 => "11000010101111", 
    33 => "11110000000011", 34 => "00011101111111", 35 => "00000011111000", 
    36 => "11101001100010", 37 => "00100111100010" );

attribute syn_rom_style : string;
attribute syn_rom_style of mem : signal is "select_rom";
attribute ROM_STYLE : string;
attribute ROM_STYLE of mem : signal is "distributed";

begin 


memory_access_guard_0: process (addr0) 
begin
      addr0_tmp <= addr0;
--synthesis translate_off
      if (CONV_INTEGER(addr0) > mem_size-1) then
           addr0_tmp <= (others => '0');
      else 
           addr0_tmp <= addr0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(addr0_tmp)); 
        end if;
    end if;
end process;

end rtl;

Library IEEE;
use IEEE.std_logic_1164.all;

entity LcwtMLP_RFFI_FC2_bCo is
    generic (
        DataWidth : INTEGER := 14;
        AddressRange : INTEGER := 38;
        AddressWidth : INTEGER := 6);
    port (
        reset : IN STD_LOGIC;
        clk : IN STD_LOGIC;
        address0 : IN STD_LOGIC_VECTOR(AddressWidth - 1 DOWNTO 0);
        ce0 : IN STD_LOGIC;
        q0 : OUT STD_LOGIC_VECTOR(DataWidth - 1 DOWNTO 0));
end entity;

architecture arch of LcwtMLP_RFFI_FC2_bCo is
    component LcwtMLP_RFFI_FC2_bCo_rom is
        port (
            clk : IN STD_LOGIC;
            addr0 : IN STD_LOGIC_VECTOR;
            ce0 : IN STD_LOGIC;
            q0 : OUT STD_LOGIC_VECTOR);
    end component;



begin
    LcwtMLP_RFFI_FC2_bCo_rom_U :  component LcwtMLP_RFFI_FC2_bCo_rom
    port map (
        clk => clk,
        addr0 => address0,
        ce0 => ce0,
        q0 => q0);

end architecture;


